<?php

namespace App\Controllers;

class Pages extends BaseController
{
    protected $nilai;
    public function __construct()
    {
        $this->nilai = new \App\Models\ModelNilai();
    }
    public function index()
    {
        $skor = $this->nilai->findAll();
        $data = [
            'judul' => 'Statistik | Tugas CI',
            'nilai' => $skor
        ];
        // dd($skor);
        return view('home', $data);
    }
    public function addData()
    {
        $data = [
            'judul' => 'Statistik | Tugas CI',
        ];
        return view('add', $data);
    }
    public function save()
    {
        $this->nilai->save([
            'mapel' => $this->request->getVar('mapel'),
            'Nilai' => $this->request->getVar('Nilai')
        ]);
        return redirect()->to('/pages/index');
    }

    public function delete($id)
    {
        $this->nilai->delete($id);
        return redirect()->to('/pages/index');
    }
}
