<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h5 class="my-6">Tambahkan Data</h5>
            <form action="/pages/save" method="POST">
                <div class="mb-3">
                    <label for="mapel" class="form-label">Nama Mata Pelajaran</label>
                    <input type="text" class="form-control" id="mapel" name="mapel">
                </div>
                <div class="mb-3">
                    <label for="Nilai" class="form-label">Nilai</label>
                    <input type="number" class="form-control" id="Nilai" name="Nilai">
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>