<?php

namespace App\Models;

use CodeIgniter\Model;

class ModelNilai extends Model
{
    protected $table = 'nilai';
    // protected $useTimestamps = true;
    protected $allowedFields = ['mapel', 'Nilai'];
}
